create definer = admin@`%` trigger user_point_trigger
    before insert
    on user_point
    for each row
    SET
    NEW.createAt = IFNULL(NEW.createAt, NOW()),
    NEW.expiredAt = TIMESTAMPADD(MONTH, 3, NEW.expiredAt);

